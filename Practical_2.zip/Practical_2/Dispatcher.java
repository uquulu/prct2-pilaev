public class Dispatcher {
    private int id;
    private String name;
    private String surname;
    private String login;
    private String password;
    private String phone;
    private String workShift;

    public Dispatcher() {}

    public Dispatcher(int id, String name, String surname, String login,
                      String password, String phone, String workShift) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.login = login;
        this.password = password;
        this.phone = phone;
        this.workShift = workShift;
    }

    public void controlTransportMovement() {}
    public void viewVehicleLocation() {}
    public void controlSchedule() {}
    public void detectDelays() {}
    public void receiveFaultNotifications() {}
    public void sendInformationToDrivers() {}

    @Override
    public String toString() {
        return "Dispatcher{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", login='" + login + '\'' +
                ", password='" + password + '\'' +
                ", phone='" + phone + '\'' +
                ", workShift='" + workShift + '\'' +
                '}';
    }
}
