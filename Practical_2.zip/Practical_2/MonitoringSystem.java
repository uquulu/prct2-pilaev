public class MonitoringSystem {
    private int systemId;
    private String name;
    private String softwareVersion;
    private int connectedVehiclesCount;
    private int activeRoutesCount;
    private int connectedGpsTrackersCount;
    private String systemStatus;

    public MonitoringSystem() {}

    public MonitoringSystem(int systemId, String name, String softwareVersion,
                            int connectedVehiclesCount, int activeRoutesCount,
                            int connectedGpsTrackersCount, String systemStatus) {
        this.systemId = systemId;
        this.name = name;
        this.softwareVersion = softwareVersion;
        this.connectedVehiclesCount = connectedVehiclesCount;
        this.activeRoutesCount = activeRoutesCount;
        this.connectedGpsTrackersCount = connectedGpsTrackersCount;
        this.systemStatus = systemStatus;
    }

    public void receiveGpsData() {}
    public void storeTransportInformation() {}
    public void trackVehicles() {}
    public void processCoordinates() {}
    public void calculateArrivalTime() {}
    public void transmitInformationToDisplays() {}
    public void providePassengerInformation() {}
    public void notifyDispatchers() {}

    @Override
    public String toString() {
        return "MonitoringSystem{" +
                "systemId=" + systemId +
                ", name='" + name + '\'' +
                ", softwareVersion='" + softwareVersion + '\'' +
                ", connectedVehiclesCount=" + connectedVehiclesCount +
                ", activeRoutesCount=" + activeRoutesCount +
                ", connectedGpsTrackersCount=" + connectedGpsTrackersCount +
                ", systemStatus='" + systemStatus + '\'' +
                '}';
    }
}
