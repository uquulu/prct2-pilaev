import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        Passenger passenger = new Passenger(
                1,
                "Олексій",
                "+380501234567",
                "oleksii@example.com",
                Arrays.asList("12", "18"),
                Arrays.asList("Центральна", "Вокзальна")
        );

        Driver driver = new Driver(
                2,
                "Іван",
                "Петренко",
                "+380671234567",
                "AB123456",
                "Богдан А092",
                "12"
        );

        TransportVehicle vehicle = new TransportVehicle(
                3,
                "BH1234AA",
                "Автобус",
                "Богдан",
                "А092",
                2019,
                "12",
                42.5,
                "46.4825, 30.7233",
                "На маршруті"
        );

        Route route = new Route(
                "12",
                "Центр — Вокзал",
                "Центральна",
                "Вокзальна",
                Arrays.asList("Центральна", "Парк", "Вокзальна"),
                8.5,
                35,
                "06:00–22:00"
        );

        Stop stop = new Stop(
                5,
                "Центральна",
                "вул. Дерибасівська, 1",
                "46.4825, 30.7233",
                Arrays.asList("12", "18"),
                1
        );

        GpsTracker gpsTracker = new GpsTracker(
                6,
                "GPS-001",
                "46.4825, 30.7233",
                42.5,
                "05.10.2026 19:00",
                "Підключено",
                "BH1234AA"
        );

        Dispatcher dispatcher = new Dispatcher(
                7,
                "Петро",
                "Іваненко",
                "dispatcher01",
                "password123",
                "+380931234567",
                "08:00–20:00"
        );

        ElectronicDisplay display = new ElectronicDisplay(
                8,
                "вул. Дерибасівська, 1",
                1,
                "Працює",
                "Маршрут 12 — прибуття через 5 хв",
                "05.10.2026 19:00"
        );

        MonitoringSystem system = new MonitoringSystem(
                9,
                "Система моніторингу громадського транспорту",
                "1.0.0",
                25,
                10,
                25,
                "Активна"
        );

        System.out.println(passenger);
        System.out.println(driver);
        System.out.println(vehicle);
        System.out.println(route);
        System.out.println(stop);
        System.out.println(gpsTracker);
        System.out.println(dispatcher);
        System.out.println(display);
        System.out.println(system);
    }
}
