public class TransportVehicle {
    private int id;
    private String registrationNumber;
    private String transportType;
    private String brand;
    private String model;
    private int year;
    private String routeNumber;
    private double currentSpeed;
    private String currentCoordinates;
    private String status;

    public TransportVehicle() {}

    public TransportVehicle(int id, String registrationNumber, String transportType,
                            String brand, String model, int year, String routeNumber,
                            double currentSpeed, String currentCoordinates, String status) {
        this.id = id;
        this.registrationNumber = registrationNumber;
        this.transportType = transportType;
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.routeNumber = routeNumber;
        this.currentSpeed = currentSpeed;
        this.currentCoordinates = currentCoordinates;
        this.status = status;
    }

    public void transportPassengers() {}
    public void followRoute() {}
    public void transmitLocation() {}
    public void transmitSpeed() {}
    public void reportStatus() {}

    @Override
    public String toString() {
        return "TransportVehicle{" +
                "id=" + id +
                ", registrationNumber='" + registrationNumber + '\'' +
                ", transportType='" + transportType + '\'' +
                ", brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                ", year=" + year +
                ", routeNumber='" + routeNumber + '\'' +
                ", currentSpeed=" + currentSpeed +
                ", currentCoordinates='" + currentCoordinates + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
